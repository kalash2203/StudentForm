package com.example.navkardreamsoft

data class Student(

    var id: String,
    val name: String,
    val contactNumber: String,
    val email: String,
    val registrationFees: Double,
    val collegeFees: Double,
    val examFees: Double,
    val totalFees: Double

)


package com.example.navkardreamsoft

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase


class MainActivity : AppCompatActivity() {

        private lateinit var database: FirebaseDatabase

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            // Initialize Firebase database
            database = FirebaseDatabase.getInstance()

            // Get references to UI elements
            val nameEditText = findViewById<EditText>(R.id.etFirstName)
            val contactNumberEditText = findViewById<EditText>(R.id.etContactNumber)
            val emailEditText = findViewById<EditText>(R.id.etEmail)
            val regFeesEditText = findViewById<EditText>(R.id.etRegistrationFees)
            val collegeFeesEditText = findViewById<EditText>(R.id.etCollegeFees)
            val examFeesEditText = findViewById<EditText>(R.id.etExamFees)
            val totalFeesTextView = findViewById<TextView>(R.id.tvTotalFees)
            val saveButton = findViewById<Button>(R.id.btnSubmit)

            // Set a click listener for the save button
            saveButton.setOnClickListener {
                // Get the input values from the UI elements
                val name = nameEditText.text.toString().trim()
                val contactNumber = contactNumberEditText.text.toString().trim()
                val email = emailEditText.text.toString().trim()
                val regFeesString = regFeesEditText.text.toString().trim()
                val collegeFeesString = collegeFeesEditText.text.toString().trim()
                val examFeesString = examFeesEditText.text.toString().trim()

                // Validate the input values
                if (name.isEmpty()) {
                    Toast.makeText(this, "Please enter a name", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (!isValidContactNumber(contactNumber)) {
                    Toast.makeText(this, "Please enter a valid contact number", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (!isValidEmail(email)) {
                    Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                if (!isValidNumericValue(regFeesString) || !isValidNumericValue(collegeFeesString) || !isValidNumericValue(examFeesString)) {
                    Toast.makeText(this, "Please enter valid numeric values for fees", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                // Convert the fees strings to numeric values
                val regFees = regFeesString.toDouble()
                val collegeFees = collegeFeesString.toDouble()
                val examFees = examFeesString.toDouble()

                // Calculate the total fees
                
                val totalFees = regFees + collegeFees + examFees

                // Update the UI with the total fees
                totalFeesTextView.text = String.format("%.2f", totalFees)

                // Create a new student object with the input values
                val newStudent = Student("",name, contactNumber, email, regFees, collegeFees, examFees, totalFees)

                // Save the new student object to Firebase database
                saveStudentToFirebase(newStudent)
            }
        }

        // Function to validate a contact number (must be 10 digits, alphanumeric not allowed)
        private fun isValidContactNumber(contactNumber: String): Boolean {
            val regex = Regex("^[0-9]{10}$")
            return regex.matches(contactNumber)
        }
        // Function to validate an email address (must be in the format of "username@domain.com")
        private fun isValidEmail(email: String): Boolean {
            val regex = Regex("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")
            return regex.matches(email)
        }

        // Function to check if a string is a valid numeric value
        private fun isValidNumericValue(value: String): Boolean {
            return value.toDoubleOrNull() != null
        }

        // Function to save a student object to Firebase database
        private fun saveStudentToFirebase(student: Student) {
            // Get a reference to the "students" node in the Firebase database
            val studentsRef = database.getReference("students")

            // Generate a unique ID for the new student object
            val id = studentsRef.push().key

            // Set the ID of the new student object
            if (id != null) {
                student.id = id
            }

            // Save the new student object to the Firebase database
            studentsRef.child(id!!).setValue(student)
                .addOnSuccessListener {
                    // Show a success message
                    Toast.makeText(this, "Student saved successfully", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { exception ->
                    // Show an error message
                    Log.e("Firebase", "Error saving student: ${exception.message}")
                    Toast.makeText(this, "Error saving student", Toast.LENGTH_SHORT).show()
                }
        }
    }

